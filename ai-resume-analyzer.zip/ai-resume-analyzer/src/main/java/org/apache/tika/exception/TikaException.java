package org.apache.tika.exception;

public class TikaException {

}
