package com.raviprajapati.resumeanalyzer;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.IOException;

@WebServlet("/analyze")
@MultipartConfig
public class AnalyzeServlet extends HttpServlet {

    private final ResumeService resumeService = new ResumeService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Part resumeFile = request.getPart("resume");
        String jobDescription = request.getParameter("jd");

        if (resumeFile == null || resumeFile.getSize() == 0) {
            request.setAttribute("error", "Please upload a resume file.");
            request.getRequestDispatcher("/index.jsp").forward(request, response);
            return;
        }

        AnalysisResult result = resumeService.analyze(resumeFile, jobDescription);

        request.setAttribute("analysisResult", result);
        request.setAttribute("showResults", true);
        request.setAttribute("jdText", jobDescription);
        
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }
}
