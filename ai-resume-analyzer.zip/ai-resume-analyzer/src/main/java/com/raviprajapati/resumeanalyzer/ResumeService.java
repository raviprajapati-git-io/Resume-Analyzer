package com.raviprajapati.resumeanalyzer;

import org.apache.tika.Tika;
import org.apache.tika.exception.TikaException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class ResumeService {

    // A list of common "stop words" to ignore for a more accurate analysis
    private static final Set<String> STOP_WORDS = new HashSet<>(Arrays.asList(
            "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are", "as", "at",
            "be", "because", "been", "before", "being", "below", "between", "both", "but", "by",
            "can", "did", "do", "does", "doing", "down", "during", "each",
            "few", "for", "from", "further", "had", "has", "have", "having", "he", "her", "here", "hers", "herself",
            "him", "himself", "his", "how", "i", "if", "in", "into", "is", "it", "its", "itself",
            "just", "me", "more", "most", "my", "myself", "no", "nor", "not", "now", "of", "off", "on", "once",
            "only", "or", "other", "our", "ours", "ourselves", "out", "over", "own",
            "s", "same", "she", "should", "so", "some", "such",
            "t", "than", "that", "the", "their", "theirs", "them", "themselves", "then", "there", "these", "they",
            "this", "those", "through", "to", "too", "under", "until", "up", "very",
            "was", "we", "were", "what", "when", "where", "which", "while", "who", "whom", "why", "will", "with",
            "you", "your", "yours", "yourself", "yourselves"
    ));

    public AnalysisResult analyze(MultipartFile resumeFile, String jobDescription) {
        String resumeText;
        // Safely parse the resume file and handle potential errors
        try (InputStream stream = resumeFile.getInputStream()) {
            Tika tika = new Tika();
            resumeText = tika.parseToString(stream);
        } catch (IOException | TikaException | SAXException e) {
            System.err.println("Error parsing resume file: " + e.getMessage());
            resumeText = ""; // On error, continue with empty text to avoid crashing
        }

        // Extract meaningful keywords from the resume and job description
        Set<String> resumeKeywords = extractKeywords(resumeText);
        Set<String> jdKeywords = extractKeywords(jobDescription);

        if (jdKeywords.isEmpty()) {
            return new AnalysisResult(0, new HashSet<>(), new HashSet<>());
        }

        // Find keywords that are in both the resume and the job description
        Set<String> matchedKeywords = new HashSet<>(jdKeywords);
        matchedKeywords.retainAll(resumeKeywords);

        // Find keywords that are in the job description but NOT in the resume
        Set<String> missingKeywords = new HashSet<>(jdKeywords);
        missingKeywords.removeAll(resumeKeywords);

        // Calculate the match percentage
        double matchPercentage = ((double) matchedKeywords.size() / jdKeywords.size()) * 100;

        return new AnalysisResult(matchPercentage, matchedKeywords, missingKeywords);
    }

    /**
     * Extracts a set of meaningful keywords from a given text.
     * It converts the text to lowercase, splits it into words, and removes
     * short words and common "stop words".
     * @param text The input text to process.
     * @return A Set of unique keywords.
     */
    private Set<String> extractKeywords(String text) {
        if (text == null || text.isBlank()) {
            return new HashSet<>();
        }
        return Arrays.stream(text.toLowerCase().split("\\W+"))
                .filter(word -> word.length() > 2)
                .filter(word -> !STOP_WORDS.contains(word)) // Filter out stop words
                .collect(Collectors.toSet());
    }
}

