package com.raviprajapati.resumeanalyzer;



import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class ResumeController {

    private final ResumeService resumeService;

    public ResumeController(ResumeService resumeService) {
        this.resumeService = resumeService;
    }

    @GetMapping("/")
    public String index(Model model) {
        // This ensures the results section is hidden on the first visit
        model.addAttribute("showResults", false);
        return "index"; // Renders index.html
    }

    @PostMapping("/analyze")
    public String analyzeResume(@RequestParam("resume") MultipartFile resumeFile,
                                @RequestParam("jd") String jobDescription,
                                Model model) {
        if (resumeFile.isEmpty()) {
            model.addAttribute("error", "Please upload a resume file.");
            model.addAttribute("showResults", false);
            return "index";
        }

        AnalysisResult result = resumeService.analyze(resumeFile, jobDescription);

        // Add results to the model to be displayed in the HTML
        model.addAttribute("analysisResult", result);
        model.addAttribute("showResults", true); // Make the results section visible
        model.addAttribute("jdText", jobDescription); // Keep the job description in the textarea

        return "index"; // Re-renders index.html with the new data
    }
}
