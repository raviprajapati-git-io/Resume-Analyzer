package com.raviprajapati.resumeanalyzer;



import java.util.Set;

public class AnalysisResult {
    private double matchPercentage;
    private Set<String> matchedKeywords;
    private Set<String> missingKeywords;

    // Constructors, Getters, and Setters
    public AnalysisResult(double matchPercentage, Set<String> matchedKeywords, Set<String> missingKeywords) {
        this.matchPercentage = matchPercentage;
        this.matchedKeywords = matchedKeywords;
        this.missingKeywords = missingKeywords;
    }

    // Getters are required for Thymeleaf to access the data
    public double getMatchPercentage() { return matchPercentage; }
    public Set<String> getMatchedKeywords() { return matchedKeywords; }
    public Set<String> getMissingKeywords() { return missingKeywords; }
}